import React,{component} from 'react';
import L from 'leaflet';
import { Map, Marker, Popup, TileLayer } from 'react-leaflet'

function GetIcon(iconSize){
  return L.icon({
    iconUrl: require('../../assets/icons/map_marker.png'),
    iconSize: [iconSize]
  })
}
function MyMap(){
 const position = [12.971599,77.594566]
 const locations = [
  {'name':'Electronic city, Bangalore', 'position': [12.857967, 77.785475]},
  {'name':'Whitefield, Bangalore', 'position': [12.969860, 77.750435]},
  {'name':'Jigani, Bangalore', 'position': [12.784442, 77.638439]},
  {'name':'Maluru, Bangalore', 'position': [13.007691, 77.939917]},
  {'name':'Rajajinagar, Bangalore', 'position': [12.987668, 77.553978]},
  
 ]
    return(
        <Map className="map"
        center = {position}
        zoom={10}
        style={{"height":500, "width":"100%"}}
        >
        <TileLayer
      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/>
      { locations.map((location) => (
        <Marker position={location.position} icon={GetIcon(35)} >
          <Popup>
            {location.name}
          </Popup>
        </Marker>
      ))}
     
      </Map>
    )
}

export default MyMap;