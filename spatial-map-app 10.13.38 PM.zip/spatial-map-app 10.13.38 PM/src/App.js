import './App.css';
import MyMap from './components/Map/MyMap';
function App() {
  return (
    <div className="App">
      <MyMap/>
    </div>
  );
}

export default App;
